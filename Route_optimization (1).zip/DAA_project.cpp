#include<iostream>
#include<vector>
#include<limits>
#include<unordered_map>
#include<algorithm>

#define inf 1e9

using namespace std;


int findmin(vector<int> &dist,vector<bool> &visited,int v){
	int distance=inf,minindex;
	
	for(int i=0;i<v;i++){
		if(!visited[i] && dist[i]<distance){
			distance=dist[i];
			minindex=i;
		}
	}
	
	return minindex;
	
}




void dijkstra(int** graph,int v,int srcindex,int destindex,vector<string> &cities,unordered_map<string,int> &cityindex){
	vector<int> dist(v,inf);
	vector<bool> visited(v,false);
	vector<int> parent(v,-1);

	dist[srcindex]=0;
	parent[srcindex]=-1;
	
	for(int i=0;i<v-1;i++){
		int minindex=findmin(dist,visited,v);	
		visited[minindex]=true;
		
		if(minindex==destindex){
			break;
		}
		
		for(int j=0;j<v;j++){
			if(!visited[j] && graph[minindex][j]!=inf  &&   dist[minindex]+graph[minindex][j]<dist[j]){
				dist[j]=dist[minindex]+graph[minindex][j];
				parent[j]=minindex;
			}
		}
	}
	
	cout<<endl<<"The shortest Distance from "<<cities[srcindex]<<" To "<<cities[destindex]<<": "<<dist[destindex];
	cout<<endl;
	
	string choice;
	do{

string city;
cout<<endl<<"Enter the city you want to choose from "<<cities[srcindex]<<" To find the path:";
	cin>>city;
	
	
	if(cityindex.find(city)==cityindex.end()){
		cout<<"Error:Invalid city! "<<city<<" Please try again..."<<endl;
		continue;
	}
	
	
	vector<int> path;
	
	for(int i=cityindex[city];i!=-1;i=parent[i]){
		
		path.push_back(i);
		
	}
	
	reverse(path.begin(),path.end());
	cout<<endl;
	for(int i=0;i<path.size();i++){
		cout<<cities[path[i]];
		if(i<path.size()-1){
			cout<<"->";
		}
	}
	

	cout<<endl<<"Do you want to find another path (yes (or) no): ";
	cout<<endl;
	cin>>choice;
	}while(choice=="Yes" || choice=="yes");
	
	
}



int main(){
	
	int v,m,dist;
	string city,city1,city2;
	cout<<"Enter the number of cities: ";
	cin>>v;
	cout<<endl<<"Enter the number of connections between the cities: ";
	cin>>m;
	vector<string> cities(v);
	unordered_map<string,int> cityindex(v);
	
	int** graph=new int*[v];
	
	for(int i=0;i<v;i++){
		graph[i]=new int[v];
	}
	
	
	for(int i=0;i<v;i++){
		for(int j=0;j<v;j++){
			if(i==j){
			
			graph[i][j]=0;
		}else{
			graph[i][j]=inf;
		}
		}
	}

	cout<<endl;
	for(int i=0;i<v;i++){
		cout<<"Enter city: "<<endl;
		cin>>city;
		if(cityindex.find(city)!=cityindex.end()){
			cout<<"The city already Exists "<<city<<" Please try different city"<<endl;
			i--;
			continue;
			
		}
		cities[i]=city;
		cityindex[city]=i;
	}
	
	cout<<endl;
	for(int i=0;i<m;i++){
		cout<<"Enter city1:";
		cin>>city1;
		cout<<endl<<"Enter city2:";
		cin>>city2;
		if(cityindex.find(city1) == cityindex.end() || cityindex.find(city2) == cityindex.end()) {
        cout << "Error: One or both cities do not exist. Please re-enter the edge details."<<endl;
        i--; 
        continue;
          }
		
		cout<<endl<<"Enter the distance between them: ";
		cin>>dist;
		int u=cityindex[city1];
		int v=cityindex[city2];
		
		graph[u][v]=dist;
		graph[v][u]=dist;
		cout<<endl;
	}
	cout<<"The matrix Representation of your data input is!"<<endl;
	for(int i=0;i<v;i++){
		for(int j=0;j<v;j++){
			if(graph[i][j]==inf){
				cout<<"inf ";
			}else{
				cout<<graph[i][j]<<" ";
			}
		}
		cout<<endl;
	}
	
	cout<<endl<<"Enter the source city: ";
	string src,dest;
	cin.ignore();	 
	getline(cin,src);
	 cout<<endl<<"Enter the destination city: ";
	 getline(cin,dest);
	
	int srcindex=cityindex[src];
	int destindex=cityindex[dest]; 
	
	dijkstra(graph,v,srcindex,destindex,cities,cityindex);
	
	
	for (int i = 0; i < v; i++) {
           delete[] graph[i];
    }
    
      delete[] graph;

	
	return 0;
}
